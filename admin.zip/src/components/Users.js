import React from 'react'
import { Button, Card, Col, Container, Row, Table } from 'react-bootstrap'
import SideBar from './SideBar'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Header from './Header'
import Footer from './Footer'
import { faCircleUser, faHand, faHouseChimney } from '@fortawesome/free-solid-svg-icons'
import { useNavigate } from 'react-router-dom'
import { faBell, faPaw, faUser } from '@fortawesome/fontawesome-free-solid'

export default function Users() {
    const navigate= useNavigate();
  return (
    <>
    
    <Container fluid>
        <Row>
                <Col sm={'3'}>
{/* sidebar start */}

                  <div className=''>
                      <div className='p-5'>
                      <img src={require("../assets/images/nav-logo.png")} className='w-75 mx-auto' />
                      </div>
                      <div className='d-flex flex-column container'>
                        <div className='mt-5'>
                        <div className='d-flex flex-row sidebar-links' onClick={()=>navigate('/home')}><FontAwesomeIcon icon={faHouseChimney} className='px-3 pt-1' /><p className="">Dashboard</p></div>
                        <div className='d-flex flex-row sidebar-links text-danger' onClick={()=>navigate('/users')}><FontAwesomeIcon icon={faUser}  className='px-3 pt-1' /><p>Users</p></div>
                        <div className='d-flex flex-row sidebar-links' onClick={()=>navigate('/venues')}><FontAwesomeIcon icon={faPaw}  className='px-3 pt-1' /><p>Venues</p></div>
                        <div className='d-flex flex-row sidebar-links' onClick={()=>navigate('/booking')}><FontAwesomeIcon icon={faHand}  className='px-3 pt-1' /><p>Bookings</p></div>
                        <div className='d-flex flex-row sidebar-links' onClick={()=>navigate('/alerts')}><FontAwesomeIcon icon={faBell}  className='px-3 pt-1' /><p>Alerts</p></div>
                        </div>
                      </div>
                    </div>
      

{/* sidebar end */}
                </Col>
                <Col sm={'9'} className='table-bg'>
                <div className='my-4'><h3 className='d-inline' style={{textDecoration:'underline'}}>Users</h3><FontAwesomeIcon icon={faCircleUser} className='float-end fs-1 mx-5 text-danger-emphasis userlogo rounded-circle' /></div>
                <Row>
                    <Col>
                    <div className='overflow-auto scroll' style={{maxHeight:'600px'}}>
                    <Table bordered hover striped >
                        <thead  className="sticky-top bg-info">
                            <tr>
                                <th>id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>
                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>

                            </tr>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>

                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>

                            </tr>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>
                                
                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>


                            </tr>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>

                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>


                            </tr>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>

                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>


                            </tr>
                            <tr>
                                <td>1</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>
                                
                            </tr>
                            <tr>

                                <td>2</td>
                                <td>John Doe</td>
                                <td>john@gmail.com</td>
                                <td>john</td>
                                <td>12345</td>
                                <td><Button variant='danger'>Delete</Button></td>


                            </tr>
                            
                            
                        </tbody>
                    </Table>
                    </div>
                    </Col>
                    </Row>

                  </Col>
                  </Row>
            </Container>
       <Footer />
    </>
  )
}

import React from 'react'
import { Button, Card, FloatingLabel, Form } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

export default function Login() {
    const navigate = useNavigate();
  return (
    <>

    <div className='login-bg d-flex '>
     
    <Card className='login-card w-25 p-5 mx-auto my-auto'>
      <h2 className='text-center text-light '>Admin</h2>
     <FloatingLabel
        controlId="floatingInput"
        label="User Name"
        className="mb-3">
        <Form.Control type="email" placeholder="name@example.com" className='' />
      </FloatingLabel>
      <FloatingLabel controlId="floatingPassword" label="Password" className='mb-3'>
        <Form.Control type="password" placeholder="Password" className=' ' />
      </FloatingLabel>
      <Button variant="success" onClick={()=>navigate('/home')} className='mx-auto d-block '>Login</Button>
      </Card>
      
      </div>
    </>
  )
}
